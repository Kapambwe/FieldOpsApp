self.assetsManifest = {
  "version": "6nkVb1En",
  "assets": [
    {
      "hash": "sha256-SSQjB+DTSnp2NqC+3rHKeR8PFWoiO5XfKsn6CXMNVOU=",
      "url": "FieldOpsApp.styles.css"
    },
    {
      "hash": "sha256-O55OD2OVAl1jr3H2QcGi9yy/KX46+C863YViVL66Iuk=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-b6fkGEvF/WgaV8IzYc19kkveeOfEuvmzEMUZZ1mDouo=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-J6P6bKws8xYOnp2HEmjUhVc6GkT11SczcZQzkLqrpLE=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-s5wwUWgwrLJOUf6N5LNIauwI7T0Tidd25b2HaFZSHzc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-yq22PzZMxoOuwzGg2WAGz5EAMyBtnZe1g96CdeSqyFQ=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-ZrxMkhk8bSkguJXYhx0VSqZ5UobGLa/Up2Xp7rotuwk=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-XqOisC4ioURQ5zkXqyB3aQcdHhwN2zvOGJyik6zvqVs=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-3fs8pAJqiHOhIim0rpZsIthdLTIqvY4TSjgnvS/nfkg=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-RlYQfEsF9lBg0Kt+iAAx03wc0Hpy9lXmXJ/GBF40tcs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-SQmr+L20Xgl+zWGnIiNjX+1Aggie8NPFi3FgmBs/H+Y=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-OgG/URGDL765oEyXripH0B/7dN3dQFcXpnlAjg5dfi8=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-9eYA9KvGTJ9yINv6OFQ6dvdsrdgFG0QwDA0cDW+fNbo=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-JTVqfH7YQEbPaXo0L79fy8AMtvx0NmYtOl35RwkVO/U=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-halqu8G6vxW9t+MMiVfxCc9jG9k3aeeVTZslAB8K/5E=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-HevElI0rUMBEv0bx/J8UDo2XCby8XqY385ReiprEjkU=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-8PhRYdYmBxS5dUFiiP0dN7as2VguLg5WJ9Q70v+N39g=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-xUHUuQRXzqwPiVcKr5oCxlRfl/bPoVHY2nOBEaqgLX8=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-Tjux88it7rUI7GEhUMD+fYh3ncI/cwbPVevalWS6iB0=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-Jxg6VmzqlJP6TvCIkJc7KG3E93K4t/OsVC5hGF07CZU=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-EXzwgvuwDM4XHVXAnE+V7TTYrzK/BKtcSCYFd4dRx1w=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-jpEa8Dv8fmxLQo6Vy8zD5lhoI2EvxJySW7LaSII5VWQ=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-h0XuH2mGYhdmtmqP5y5HgCY/HprvplgfniDxIcRTSuw=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-axyk4bicFPTqkqmIsjPfWvjid9QTTKOffCbXor5ojvc=",
      "url": "_framework/FieldOpsApp.du1dtzvgk3.wasm"
    },
    {
      "hash": "sha256-RrIqvyCQR8NLr5NMtRkoaONF+ycVG7KZSIsY45vLoS0=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.qzk4ny30jw.wasm"
    },
    {
      "hash": "sha256-Cfe0kL/10AdXcfURmF+K/cIaCnDnZlhWxkGtR3rFvyM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.1uh7hs0g6y.wasm"
    },
    {
      "hash": "sha256-rNPbZpWePxNM2w5tIED5BP0+7lSPR1bzL0II8P+9FH4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.kazk01g95z.wasm"
    },
    {
      "hash": "sha256-r9vzZW7BkoMPEazZmJcwWMJVZuBu+J08yLzE76Fl22A=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jnmw96aapy.wasm"
    },
    {
      "hash": "sha256-XFg3gBUnmwNKUG3eekoysXp0GQDA+U2IrebmRQL4ZaM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.skjxjdnbnw.wasm"
    },
    {
      "hash": "sha256-f7bREleT4l4Nn84vgpzd8fajIuBaTvPWQSmhnFoQ+6c=",
      "url": "_framework/Microsoft.AspNetCore.Components.nawco07o24.wasm"
    },
    {
      "hash": "sha256-HDof6DD8xtU65Q/RhVPKVaW2y00xd8I2g3gxAneot/k=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.8t0g6je4cu.wasm"
    },
    {
      "hash": "sha256-PjsPV2iqqZHbYRoeORbPpVqTjDtGcOaHfTYLkifMxv0=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.6v680cse6m.wasm"
    },
    {
      "hash": "sha256-F3lD6tJVuB2+DUCSIAgXER3lSqE619YapH4QKgywxEA=",
      "url": "_framework/Microsoft.CSharp.12qckhcp9z.wasm"
    },
    {
      "hash": "sha256-4yiF/uCSo6eZ20smSb0Rlq7rKaCIwmAKNDMGzpz7OqU=",
      "url": "_framework/Microsoft.Extensions.Configuration.9d8zud9wr7.wasm"
    },
    {
      "hash": "sha256-13zFSTFrGK1uC2iFNhGNX9w7MwAUsEzdVsG9nn67bEg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vy7qudiyob.wasm"
    },
    {
      "hash": "sha256-hiqKKmjhzIkq/fqhFIgtKaYCzixTATJ1Mmm80PkJsYU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.i5otjqf6m7.wasm"
    },
    {
      "hash": "sha256-niwb2sZskJ7wsZsNxfs8leRiqjwIuv7eqfar1dAjILU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.qiwbq8ugx5.wasm"
    },
    {
      "hash": "sha256-WYob3eJ5JZ5ET5XXcpdH1/7t3wwTlVUO7ByA3A/XT8o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.556xh3l82c.wasm"
    },
    {
      "hash": "sha256-43AiAf7rFC4XRGEssYchxFRfXONN8XBXLDi3plCkD2s=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.7nmhsqm906.wasm"
    },
    {
      "hash": "sha256-FsDD1xCAGbahHPs4EM8NfzzGXatQxfOTX7m8HL6nC0s=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.2uffu1oll3.wasm"
    },
    {
      "hash": "sha256-98KQRZr9w7MHE1gtXgScbI/snaA8ogs4Zcnnk9ZhsMQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.bba307b5bn.wasm"
    },
    {
      "hash": "sha256-A8FVsy8d9iCgpNrcA5oM8mG+DIXGHtTffb9WlkTr3QE=",
      "url": "_framework/Microsoft.Extensions.Logging.5ucwms7sds.wasm"
    },
    {
      "hash": "sha256-lIogVE4IjSJ31gg6y5K9Tf2n6QlvZtvhVpbNIgI0RPY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.kgwp2einjb.wasm"
    },
    {
      "hash": "sha256-6g+EYKpGaJxzsRmZTykgd/G3J5WmMqNb9kF5yTabxZc=",
      "url": "_framework/Microsoft.Extensions.Options.uj2skkfzid.wasm"
    },
    {
      "hash": "sha256-LW+2Yka4la4pC2QzdVYsEptmeYkYyKiQVeEzFcmVjYM=",
      "url": "_framework/Microsoft.Extensions.Primitives.pphafqm2is.wasm"
    },
    {
      "hash": "sha256-L3o6ScQiBNjoEsgB31VKNkW9rtDoCuWxpDnaZmdLG9Q=",
      "url": "_framework/Microsoft.Extensions.Validation.9q24f4ufiz.wasm"
    },
    {
      "hash": "sha256-b3oDx6CnxrlJd3wQYFL7BPJaC0gtnVabH6OvSqSmP+0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.r99mmn9mmt.wasm"
    },
    {
      "hash": "sha256-S1jJv+AZDuSVz9qBKOY7vdHxN0s5Syn5tGKhTHFjca0=",
      "url": "_framework/Microsoft.JSInterop.l4xclch662.wasm"
    },
    {
      "hash": "sha256-b0NzcQ/WhuEk6dfW+kfIRJw2zJIqtQiRTeQqmLlpaWI=",
      "url": "_framework/Radzen.Blazor.jjzinqqg0u.wasm"
    },
    {
      "hash": "sha256-Jz2OlcrGk/rCEtaOsFJq1jcNNbIDa0uOsP77eoZrQeI=",
      "url": "_framework/System.Collections.5xz0d0668n.wasm"
    },
    {
      "hash": "sha256-4dFtsJ8zeyQOAmQ5+2GzDq8pkcq+RI2lHyDiBC1LrSI=",
      "url": "_framework/System.Collections.Concurrent.1cr6udl25g.wasm"
    },
    {
      "hash": "sha256-hWW6DlTSImrS+a0A+J578zskcIR0ZIyQ6rfE+9X5c6w=",
      "url": "_framework/System.Collections.Immutable.3usqqv1ty4.wasm"
    },
    {
      "hash": "sha256-ChPNjVjkBxc9rnZEeMYa8sHfUhIqNvKMrzmjBsXe9eQ=",
      "url": "_framework/System.Collections.NonGeneric.e3xyrzxrao.wasm"
    },
    {
      "hash": "sha256-GOUc8eLfX+VeKSRCKQQt+t62bBKWQHqPMhSJoHd3hl4=",
      "url": "_framework/System.Collections.Specialized.cjavuspxp9.wasm"
    },
    {
      "hash": "sha256-iLB/v5ymsBx034mmns4x2J284v/yxNXikHUL6Ts7BhI=",
      "url": "_framework/System.ComponentModel.0aycg6tn4n.wasm"
    },
    {
      "hash": "sha256-y2tWrBKk6cVahclUGqUpgXLVURu1mwvbSEr++LgkNzM=",
      "url": "_framework/System.ComponentModel.Annotations.j278y1l96n.wasm"
    },
    {
      "hash": "sha256-r6zkp4GEKsXLNYsFj6sjIM9+oPz/Npihrt07apha8qk=",
      "url": "_framework/System.ComponentModel.Primitives.ttigs9r6ms.wasm"
    },
    {
      "hash": "sha256-n022gNk9H+yXTZq0p3WWtwK22OOBepGQaW/TUWbf9eE=",
      "url": "_framework/System.ComponentModel.TypeConverter.puhcxrgnja.wasm"
    },
    {
      "hash": "sha256-HPfLLVfFGjM6PV53ttAnT2EpWbVUtNY4LfWg0Vv+0g8=",
      "url": "_framework/System.Console.conx1w2brs.wasm"
    },
    {
      "hash": "sha256-JWX8kg5a1bdki34c2JubUAkq3UP3Fbin+V/OX1/Izpk=",
      "url": "_framework/System.Core.tqe26a8842.wasm"
    },
    {
      "hash": "sha256-KrDCIgFst+I1QxQSPwhDPhAHeizq72ZvTamq9U6SWQw=",
      "url": "_framework/System.Data.Common.iqfqmqavnw.wasm"
    },
    {
      "hash": "sha256-VyCEtIb3umJmoXSkHPOG7CI333VD37dy/rigFZ2b+Fs=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.7whzv3zhvk.wasm"
    },
    {
      "hash": "sha256-KwXEWTXZS4p1uKg+Veev9HNs6NOaOxk4hZfTfmBBCRc=",
      "url": "_framework/System.Drawing.3uzv2f6kn7.wasm"
    },
    {
      "hash": "sha256-dxOQxmyzlMoJaAUOv1+0Q2mwy4x13LTrtlnNrFC9pEM=",
      "url": "_framework/System.Drawing.Primitives.jxcgalbgz2.wasm"
    },
    {
      "hash": "sha256-5iZiJIPtErF9At8rjyC1eB0OtNkTwIBaz8t4yef9pF8=",
      "url": "_framework/System.IO.Pipelines.artt3iooxk.wasm"
    },
    {
      "hash": "sha256-ARYtdgncpBfTbeSVvDYjs1WLC9UcyI8wrvzqi/3FcjU=",
      "url": "_framework/System.Linq.Expressions.vc30ld9zoj.wasm"
    },
    {
      "hash": "sha256-ZKSiNRu9glmbiv389+jBsPWWXq7i3zbNr6j7vuYV1R0=",
      "url": "_framework/System.Linq.Queryable.otvqk5v6c8.wasm"
    },
    {
      "hash": "sha256-3sxYKUbr3sqWN2FZkoUG6ZSxB238aNmPo/X9iL9ytp8=",
      "url": "_framework/System.Linq.y047fhlul0.wasm"
    },
    {
      "hash": "sha256-wrApBKxzie0PN8H1/dV1DKYRCV3fFd21Xct8zPo1Sjs=",
      "url": "_framework/System.Memory.28i6zbw8rc.wasm"
    },
    {
      "hash": "sha256-vd+S5MVGQ1tibQP6gcCHgfPLhZiHRP/7TmeJxiTLBjQ=",
      "url": "_framework/System.Net.Http.1fefheobhu.wasm"
    },
    {
      "hash": "sha256-O9MW8mld28YaQs3lWf4uin8rOJGVyOxIKL/v8lai4Tk=",
      "url": "_framework/System.Net.Http.Json.z6gtgv7aab.wasm"
    },
    {
      "hash": "sha256-gcSyjZCWlkUbsdHp/weRBWjtTl8KHsHa0LkHE9Xvnjw=",
      "url": "_framework/System.Net.Primitives.5j5ae3dc60.wasm"
    },
    {
      "hash": "sha256-a/3un0xTvJhVckhz4+4e7vMwdZjgAoFsy7WDfGyvdLA=",
      "url": "_framework/System.ObjectModel.rovovu1ykb.wasm"
    },
    {
      "hash": "sha256-STbgs29HNfuJGeW/KmSd3njFZeVbyJm6IZjxyZt8yfo=",
      "url": "_framework/System.Private.CoreLib.39bro4b09f.wasm"
    },
    {
      "hash": "sha256-Tvw/cKTObcK4uxxsyyxqJn2nKz6Iwt+O7btrMtknad4=",
      "url": "_framework/System.Private.Uri.mbpq53bt65.wasm"
    },
    {
      "hash": "sha256-/KqmTGBTQwazwCh/8IKiXJ0AWFurCimojdGefX60I0E=",
      "url": "_framework/System.Private.Xml.Linq.4s96qxy5kk.wasm"
    },
    {
      "hash": "sha256-ljySyXvn8mOTROa5KZBdFBKgOSa6w9dTqqni+MpGtH0=",
      "url": "_framework/System.Private.Xml.ursn6j2bmm.wasm"
    },
    {
      "hash": "sha256-q8LvPoVx5ZV9KcTjCJRWlcddLneky5GK1utJBj8ubSQ=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.zqego3xs5y.wasm"
    },
    {
      "hash": "sha256-YqFe3eFpQcF5tqhmAOkE8P22D+6q3/fT/96PdRuFEaA=",
      "url": "_framework/System.Reflection.Emit.qauwc9f8sx.wasm"
    },
    {
      "hash": "sha256-ngxdVSxRZeKtUTywyO9kglKfmVBvN0/wzM65a6T7nkM=",
      "url": "_framework/System.Reflection.Primitives.63fkyau3se.wasm"
    },
    {
      "hash": "sha256-pg1DdfEus8MgtvuevXJW7tX0CHVfSV+Zu9N/Xlo6NMY=",
      "url": "_framework/System.Runtime.InteropServices.606hh9eikf.wasm"
    },
    {
      "hash": "sha256-IeA7pB0f/o3eZVGm+sIm8RKPcsD69THNJym/etwOWYI=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.bp9v1jxw1s.wasm"
    },
    {
      "hash": "sha256-0KEtZc+fS+sclroArGP57/AUuPt9PjD5v4nc2jScRhA=",
      "url": "_framework/System.Runtime.s5ch6xm8r8.wasm"
    },
    {
      "hash": "sha256-xfUx841mHNWTa25BNpczidz8Kxltdv4j4FWNKC/FbF0=",
      "url": "_framework/System.Security.Claims.jenrbwfs7d.wasm"
    },
    {
      "hash": "sha256-/xYxHC1kn+7sx+OOX07MJauwWNE3EH0XZVJ/L50Iam0=",
      "url": "_framework/System.Security.Cryptography.96mf7xwhxv.wasm"
    },
    {
      "hash": "sha256-t5giQdf8+U1bgTS+SDlqmhA1qDEmJ5rAlr9gJ+Zn4qM=",
      "url": "_framework/System.Text.Encodings.Web.70fzedw1k9.wasm"
    },
    {
      "hash": "sha256-s2cwXr6u9s9D9LXg5jW3I0CIytvmg4nTWLqDZwAeU28=",
      "url": "_framework/System.Text.Json.fhc67r3oqr.wasm"
    },
    {
      "hash": "sha256-4DZC0h0J6VcY4ayvbKlOJq/kFo+Hg7tyMjlpF92wy+k=",
      "url": "_framework/System.Text.RegularExpressions.oamkporjqx.wasm"
    },
    {
      "hash": "sha256-6MSIqp72YMQ+Nc64cHfUf3WsWfc5Y5T7fx3fJ/m2NDc=",
      "url": "_framework/System.Threading.sbwxzgq72i.wasm"
    },
    {
      "hash": "sha256-3J8Be8GH36TDlvGVIm7tkQM3Q1gSUMtADFiqnFlli/s=",
      "url": "_framework/System.Web.HttpUtility.44pw5lkdxc.wasm"
    },
    {
      "hash": "sha256-B45e+WTL2VicVkqRzonMAYf3a4yI96CpyM4IYzSqzNw=",
      "url": "_framework/System.Xml.Linq.55sa1dphju.wasm"
    },
    {
      "hash": "sha256-iV8Jjf9KrHpK9g4VJpZeK2UjyJoJ3PivCmHE3pJcY74=",
      "url": "_framework/System.Xml.XDocument.hif44loflj.wasm"
    },
    {
      "hash": "sha256-20jVhUzIwd4iBa37tc3g3OaofHfBeJaMcRCVn9IZFoU=",
      "url": "_framework/System.fv399lvvsg.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.958z1vx7fr.js"
    },
    {
      "hash": "sha256-YA81Z4JJMWUk4+IcxJvw+afyOcZkI6IhaUY2IbgFDa4=",
      "url": "_framework/dotnet.native.8yhigd4hxd.wasm"
    },
    {
      "hash": "sha256-trRPYs1LiZHo8Tdyibj7A6K+GtYuAFUS/OVVdYmyR5s=",
      "url": "_framework/dotnet.native.iizqdaooi1.js"
    },
    {
      "hash": "sha256-k9t+DxvKf7l/bl6dE6L0rb4Lpntm2rnmnr1SMa7Qh3g=",
      "url": "_framework/dotnet.nv28vninre.js"
    },
    {
      "hash": "sha256-cajUr4vA/MpLPWj3omULUOwEQw3i8CE2n8AmDheqWBM=",
      "url": "_framework/dotnet.runtime.peu2mfb29t.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NNyN9kssaxPuUKKgfUPnW6xM+ej0EAFwSCzFmxMJOyM=",
      "url": "appsettings.GitHub.json"
    },
    {
      "hash": "sha256-QRRz1OakeNknbxsHIcC/6Ba2mOpfJFp43WZ3cqIuKpk=",
      "url": "appsettings.Production.json"
    },
    {
      "hash": "sha256-5xgBj50mDD7rxU1lP8w4nVqg4RlO3GnqEDeDF0fPdfQ=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-mlbqtiv11EQ1BWrCkVQ01N4jF30F8lRN0llB4jIhmfY=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-YxklnMkNLlkTXEXZF891iE+gNVv5gzUdaAyWxGyZt3o=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fjBMU0TSFaXtkjC7c7fnmiMVC5LdUPg7psR3LrPmJHI=",
      "url": "js/connectivity.js"
    },
    {
      "hash": "sha256-WJcQqATylKST/HOKGlYUP8wNd7sx2tOXWCdKF5E/kNo=",
      "url": "js/fieldCamera.js"
    },
    {
      "hash": "sha256-lRM5e2isTZTg3+YMXV8wj5Ih8xPfg5KO5bT89vE9j00=",
      "url": "js/fieldSensors.js"
    },
    {
      "hash": "sha256-BLc+gOjPyhl0vwdE4kgulSASuLXAX4SQR1yWFvW0hAY=",
      "url": "js/fieldShare.js"
    },
    {
      "hash": "sha256-gZAwjPsFoo73FaX9K6Cd3K/g20E+DK6z6xbAG2VjJfw=",
      "url": "js/indexedDbService.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-HwPEeqzxKRA+z0H43/vTnWKy7sQLgc8ZZ1Qm/kSS3Nk=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-kUim9pqPRK1Hwdq96qF1F05+D+zwzvbfJ7mIlR08Dag=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-gTIm85WdarfhciNy9LC3iswahcrhHabaGGZd2rUwMhA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Mgwd4CwZjs8GEFpy2ErN1jyreJP6OC97p9SIGCYGnCk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-EUhv9/bhIJUtlyCDEWriid3aO6qZv3AMjjH7emEpoPY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-DJlFrzbrus6xcWsVUGWq2Cu6IfMDBAEZYc5qqU7MnwM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-F/jgmCzhz5rdR2pqoRE9UW/d7brTWHYmGbIUjMJMxXs=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-UeTa2SgexZHVzkBvZ+VSc2EU++fIkiu6cnE9fO6ZBM4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-jOpMCaiFLYdXM5FBSxzGSn6OeDtLSLiN9koclpx1JjE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-A3/ygJMQ5xcYejifd49/kpXu/x8x7ldSm6RFyRdkMZ8=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-42dpJm7iKg7utUdNx7/XKVFbujC/nuMl3KhLsqbR2bk=",
      "url": "sample-data/South Africa/African National Congress/assignments.json"
    },
    {
      "hash": "sha256-Y7GBoIwmJEJocUjkvHk/STpW+0iE85f4tRqand7tPSg=",
      "url": "sample-data/South Africa/African National Congress/campaigns.json"
    },
    {
      "hash": "sha256-RkbLIyrctu1ylom+Rwf1R8moHf75Mw0hkq/WGJaR6fs=",
      "url": "sample-data/South Africa/African National Congress/voters.json"
    },
    {
      "hash": "sha256-XccFc1+F+OFtl6JPVT5Z1V+hFdVs/MJ+mPmQRtbczVw=",
      "url": "sample-data/South Africa/Democratic Alliance/assignments.json"
    },
    {
      "hash": "sha256-VsUZaKFpEuySJNjhbHRJnPZW6bz2KiSbAnCTpqLEgRE=",
      "url": "sample-data/South Africa/Democratic Alliance/campaigns.json"
    },
    {
      "hash": "sha256-Hi6LdXlfFFK06xu9EiRywlJJROFmNgHau7XtgPdIcCI=",
      "url": "sample-data/South Africa/Democratic Alliance/voters.json"
    },
    {
      "hash": "sha256-3eC8vMK8SrEtcmIdR0GotoVeRnsr5Iwrm0VSa66A45I=",
      "url": "sample-data/Zambia/Citizen First/campaigns.json"
    },
    {
      "hash": "sha256-HMEK+0xeJEkvgFQ9vL2pv6YqtGoV5Kvor8gl1aDDykQ=",
      "url": "sample-data/Zambia/Patriotic Front/campaigns.json"
    },
    {
      "hash": "sha256-WeU9ZCP+kSH9wgFMI/4YYyzdid2FkaDzrIORFFVUKhw=",
      "url": "sample-data/Zambia/Socialist Party/campaigns.json"
    },
    {
      "hash": "sha256-XdXGJhsAKWccRZ3hWg8Fg4ohVz6sZcDQvbi6XvC1jx8=",
      "url": "sample-data/Zambia/United Party for National Development/assignments.json"
    },
    {
      "hash": "sha256-Dluy9sT8M6hOChRHqTfFHHQ2k2t/KRO08oTP28pN/Ko=",
      "url": "sample-data/Zambia/United Party for National Development/campaigns.json"
    },
    {
      "hash": "sha256-SZ53cHl51KZxw4SBi7JU4xUGelLX+fVrJWvjxdDh6m4=",
      "url": "sample-data/Zambia/United Party for National Development/voters.json"
    },
    {
      "hash": "sha256-RUe3HcvM0YHnRBbMxrPaFGN8ML6bqVA0x1eO26b5dbA=",
      "url": "sample-data/auth-config.json"
    },
    {
      "hash": "sha256-c275Bx0cUpfc1DjajNQn4es9+UhfIxcUJ3HQGF8uKsw=",
      "url": "sample-data/field-catalogs.json"
    },
    {
      "hash": "sha256-umGP1JvxVrx4DIfjatJwxoeoovSPoNCNncoKgDD6j+4=",
      "url": "sample-data/observer-incident-form.bem.json"
    },
    {
      "hash": "sha256-rlySrr53fxjRZiN7I4gNRMWAzyb90xGGW57uVxdiRSI=",
      "url": "sample-data/observer-incident-form.en.json"
    },
    {
      "hash": "sha256-bALjp5743GWIVLGn9ZEf2WnxvmuzgDEWRGuGP6JKPZo=",
      "url": "sample-data/observer-incident-form.fr.json"
    },
    {
      "hash": "sha256-rlySrr53fxjRZiN7I4gNRMWAzyb90xGGW57uVxdiRSI=",
      "url": "sample-data/observer-incident-form.json"
    },
    {
      "hash": "sha256-YLAvagOLaTfZ/DsbZGrZewDpD5Kp0PMkWVp5g0uhpp4=",
      "url": "sample-data/observer-incident-form.ny.json"
    },
    {
      "hash": "sha256-uy2atgNzlrY48TCNaEkAqQtG+HTe4Qv/6DvHX55hFKA=",
      "url": "sample-data/observer-incident-form.toi.json"
    },
    {
      "hash": "sha256-80unkJJyOmNySjS0/vBEE3VNYJGY/p4hUNyVUuKCc/M=",
      "url": "sample-data/search-config.json"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
