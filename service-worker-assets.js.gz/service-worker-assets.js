self.assetsManifest = {
  "version": "YCkPBfNJ",
  "assets": [
    {
      "hash": "sha256-SSQjB+DTSnp2NqC+3rHKeR8PFWoiO5XfKsn6CXMNVOU=",
      "url": "FieldOpsApp.styles.css"
    },
    {
      "hash": "sha256-O55OD2OVAl1jr3H2QcGi9yy/KX46+C863YViVL66Iuk=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.js"
    },
    {
      "hash": "sha256-b6fkGEvF/WgaV8IzYc19kkveeOfEuvmzEMUZZ1mDouo=",
      "url": "_content/Radzen.Blazor/Radzen.Blazor.min.js"
    },
    {
      "hash": "sha256-J6P6bKws8xYOnp2HEmjUhVc6GkT11SczcZQzkLqrpLE=",
      "url": "_content/Radzen.Blazor/css/dark-base.css"
    },
    {
      "hash": "sha256-ba5jk4VpM47N9NG4uP7BgaSEOCTNchIfprC2q+2vhZY=",
      "url": "_content/Radzen.Blazor/css/dark-wcag.css"
    },
    {
      "hash": "sha256-s5wwUWgwrLJOUf6N5LNIauwI7T0Tidd25b2HaFZSHzc=",
      "url": "_content/Radzen.Blazor/css/dark.css"
    },
    {
      "hash": "sha256-yq22PzZMxoOuwzGg2WAGz5EAMyBtnZe1g96CdeSqyFQ=",
      "url": "_content/Radzen.Blazor/css/default-base.css"
    },
    {
      "hash": "sha256-XI6Yl4ha60fO4EBXnZvovhvUuwyZlM+b8Sobk1mx6EA=",
      "url": "_content/Radzen.Blazor/css/default-wcag.css"
    },
    {
      "hash": "sha256-ZrxMkhk8bSkguJXYhx0VSqZ5UobGLa/Up2Xp7rotuwk=",
      "url": "_content/Radzen.Blazor/css/default.css"
    },
    {
      "hash": "sha256-XqOisC4ioURQ5zkXqyB3aQcdHhwN2zvOGJyik6zvqVs=",
      "url": "_content/Radzen.Blazor/css/humanistic-base.css"
    },
    {
      "hash": "sha256-3fs8pAJqiHOhIim0rpZsIthdLTIqvY4TSjgnvS/nfkg=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-base.css"
    },
    {
      "hash": "sha256-Xqvqc+VCZGhC/DXp1jvQzwdJFe3u84K8/UnkZGzSDOo=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark-wcag.css"
    },
    {
      "hash": "sha256-RlYQfEsF9lBg0Kt+iAAx03wc0Hpy9lXmXJ/GBF40tcs=",
      "url": "_content/Radzen.Blazor/css/humanistic-dark.css"
    },
    {
      "hash": "sha256-ofM6x2gz3BmBoEF0pC8qvo606C/dFcapf7j5UYKNqNI=",
      "url": "_content/Radzen.Blazor/css/humanistic-wcag.css"
    },
    {
      "hash": "sha256-SQmr+L20Xgl+zWGnIiNjX+1Aggie8NPFi3FgmBs/H+Y=",
      "url": "_content/Radzen.Blazor/css/humanistic.css"
    },
    {
      "hash": "sha256-OgG/URGDL765oEyXripH0B/7dN3dQFcXpnlAjg5dfi8=",
      "url": "_content/Radzen.Blazor/css/material-base.css"
    },
    {
      "hash": "sha256-9eYA9KvGTJ9yINv6OFQ6dvdsrdgFG0QwDA0cDW+fNbo=",
      "url": "_content/Radzen.Blazor/css/material-dark-base.css"
    },
    {
      "hash": "sha256-UzXkBax/wEuxozJM09HERjex3EmfhfjpXrFTG0ajRgc=",
      "url": "_content/Radzen.Blazor/css/material-dark-wcag.css"
    },
    {
      "hash": "sha256-JTVqfH7YQEbPaXo0L79fy8AMtvx0NmYtOl35RwkVO/U=",
      "url": "_content/Radzen.Blazor/css/material-dark.css"
    },
    {
      "hash": "sha256-qtnKeCVAuqhWrs0i3bqVFeynY0aA7zYDhC2svNOWr1U=",
      "url": "_content/Radzen.Blazor/css/material-wcag.css"
    },
    {
      "hash": "sha256-halqu8G6vxW9t+MMiVfxCc9jG9k3aeeVTZslAB8K/5E=",
      "url": "_content/Radzen.Blazor/css/material.css"
    },
    {
      "hash": "sha256-HevElI0rUMBEv0bx/J8UDo2XCby8XqY385ReiprEjkU=",
      "url": "_content/Radzen.Blazor/css/software-base.css"
    },
    {
      "hash": "sha256-8PhRYdYmBxS5dUFiiP0dN7as2VguLg5WJ9Q70v+N39g=",
      "url": "_content/Radzen.Blazor/css/software-dark-base.css"
    },
    {
      "hash": "sha256-65raUWhCd5dMrCoX1Xlht6tXyKCvr7KfQEcuRfNdYi4=",
      "url": "_content/Radzen.Blazor/css/software-dark-wcag.css"
    },
    {
      "hash": "sha256-xUHUuQRXzqwPiVcKr5oCxlRfl/bPoVHY2nOBEaqgLX8=",
      "url": "_content/Radzen.Blazor/css/software-dark.css"
    },
    {
      "hash": "sha256-Urzd3NajYELeK+GSlYdW+h5YA0Q3Lh3PAxNVyL7Ts8U=",
      "url": "_content/Radzen.Blazor/css/software-wcag.css"
    },
    {
      "hash": "sha256-Tjux88it7rUI7GEhUMD+fYh3ncI/cwbPVevalWS6iB0=",
      "url": "_content/Radzen.Blazor/css/software.css"
    },
    {
      "hash": "sha256-Jxg6VmzqlJP6TvCIkJc7KG3E93K4t/OsVC5hGF07CZU=",
      "url": "_content/Radzen.Blazor/css/standard-base.css"
    },
    {
      "hash": "sha256-EXzwgvuwDM4XHVXAnE+V7TTYrzK/BKtcSCYFd4dRx1w=",
      "url": "_content/Radzen.Blazor/css/standard-dark-base.css"
    },
    {
      "hash": "sha256-wER4Hw8UsyMQ8dpzQ0zPqerhi9q20UDnU6wXVA+DHDo=",
      "url": "_content/Radzen.Blazor/css/standard-dark-wcag.css"
    },
    {
      "hash": "sha256-jpEa8Dv8fmxLQo6Vy8zD5lhoI2EvxJySW7LaSII5VWQ=",
      "url": "_content/Radzen.Blazor/css/standard-dark.css"
    },
    {
      "hash": "sha256-GB0eMTCmcGSC1BZq7eQHJD8QU7HD1Pf4amekZzMQQ0M=",
      "url": "_content/Radzen.Blazor/css/standard-wcag.css"
    },
    {
      "hash": "sha256-h0XuH2mGYhdmtmqP5y5HgCY/HprvplgfniDxIcRTSuw=",
      "url": "_content/Radzen.Blazor/css/standard.css"
    },
    {
      "hash": "sha256-Yq39yM2friLMhdMdgAftsVQ9Ar3ZCargnHWNft/XIh0=",
      "url": "_content/Radzen.Blazor/fonts/MaterialSymbolsOutlined.woff2"
    },
    {
      "hash": "sha256-D4n6QkbzuJDYChkHTPMXLxJlSC/5uucOpe2kU+JCJRs=",
      "url": "_content/Radzen.Blazor/fonts/RobotoFlex.woff2"
    },
    {
      "hash": "sha256-tJWavAVpOS+HxsasYS+Q4/4BBNKDckGJt9i29hrzR9M=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Italic.ttf.woff2"
    },
    {
      "hash": "sha256-XxZWb3pA05szmtJr4VH6Whqx8MJXTHouYZdlWEoay9g=",
      "url": "_content/Radzen.Blazor/fonts/SourceSans3VF-Upright.ttf.woff2"
    },
    {
      "hash": "sha256-a5nXXt2L/SokSptPVB1z1MD8Xquf/9Cw0M6zD8WodOg=",
      "url": "_framework/CompanyApp.Shared.Sync.Contracts.fnuxs5ji2b.wasm"
    },
    {
      "hash": "sha256-q8REakkq+x5V8jjWVxOjyV7UKPOPhuWJeb9q3adkLvo=",
      "url": "_framework/FieldOpsApp.b4h02vdyrp.wasm"
    },
    {
      "hash": "sha256-NrsXsDk45QFXnHcpZkSM/qvcoyXgit68HFJ/czuYwwY=",
      "url": "_framework/Microsoft.AspNetCore.Authorization.ixwe91t4a9.wasm"
    },
    {
      "hash": "sha256-Cfe0kL/10AdXcfURmF+K/cIaCnDnZlhWxkGtR3rFvyM=",
      "url": "_framework/Microsoft.AspNetCore.Components.Authorization.1uh7hs0g6y.wasm"
    },
    {
      "hash": "sha256-rNPbZpWePxNM2w5tIED5BP0+7lSPR1bzL0II8P+9FH4=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.kazk01g95z.wasm"
    },
    {
      "hash": "sha256-r9vzZW7BkoMPEazZmJcwWMJVZuBu+J08yLzE76Fl22A=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.jnmw96aapy.wasm"
    },
    {
      "hash": "sha256-XFg3gBUnmwNKUG3eekoysXp0GQDA+U2IrebmRQL4ZaM=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.skjxjdnbnw.wasm"
    },
    {
      "hash": "sha256-f7bREleT4l4Nn84vgpzd8fajIuBaTvPWQSmhnFoQ+6c=",
      "url": "_framework/Microsoft.AspNetCore.Components.nawco07o24.wasm"
    },
    {
      "hash": "sha256-HDof6DD8xtU65Q/RhVPKVaW2y00xd8I2g3gxAneot/k=",
      "url": "_framework/Microsoft.AspNetCore.Metadata.8t0g6je4cu.wasm"
    },
    {
      "hash": "sha256-PjsPV2iqqZHbYRoeORbPpVqTjDtGcOaHfTYLkifMxv0=",
      "url": "_framework/Microsoft.AspNetCore.WebUtilities.6v680cse6m.wasm"
    },
    {
      "hash": "sha256-nFi9lEH04Cof+9d0iiKKfAgFkqFlvofUvjvhjCnWKtM=",
      "url": "_framework/Microsoft.CSharp.kys4tkalo5.wasm"
    },
    {
      "hash": "sha256-4yiF/uCSo6eZ20smSb0Rlq7rKaCIwmAKNDMGzpz7OqU=",
      "url": "_framework/Microsoft.Extensions.Configuration.9d8zud9wr7.wasm"
    },
    {
      "hash": "sha256-13zFSTFrGK1uC2iFNhGNX9w7MwAUsEzdVsG9nn67bEg=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.vy7qudiyob.wasm"
    },
    {
      "hash": "sha256-hiqKKmjhzIkq/fqhFIgtKaYCzixTATJ1Mmm80PkJsYU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Binder.i5otjqf6m7.wasm"
    },
    {
      "hash": "sha256-niwb2sZskJ7wsZsNxfs8leRiqjwIuv7eqfar1dAjILU=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.qiwbq8ugx5.wasm"
    },
    {
      "hash": "sha256-WYob3eJ5JZ5ET5XXcpdH1/7t3wwTlVUO7ByA3A/XT8o=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.556xh3l82c.wasm"
    },
    {
      "hash": "sha256-43AiAf7rFC4XRGEssYchxFRfXONN8XBXLDi3plCkD2s=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.7nmhsqm906.wasm"
    },
    {
      "hash": "sha256-FsDD1xCAGbahHPs4EM8NfzzGXatQxfOTX7m8HL6nC0s=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.Abstractions.2uffu1oll3.wasm"
    },
    {
      "hash": "sha256-98KQRZr9w7MHE1gtXgScbI/snaA8ogs4Zcnnk9ZhsMQ=",
      "url": "_framework/Microsoft.Extensions.Diagnostics.bba307b5bn.wasm"
    },
    {
      "hash": "sha256-A8FVsy8d9iCgpNrcA5oM8mG+DIXGHtTffb9WlkTr3QE=",
      "url": "_framework/Microsoft.Extensions.Logging.5ucwms7sds.wasm"
    },
    {
      "hash": "sha256-lIogVE4IjSJ31gg6y5K9Tf2n6QlvZtvhVpbNIgI0RPY=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.kgwp2einjb.wasm"
    },
    {
      "hash": "sha256-6g+EYKpGaJxzsRmZTykgd/G3J5WmMqNb9kF5yTabxZc=",
      "url": "_framework/Microsoft.Extensions.Options.uj2skkfzid.wasm"
    },
    {
      "hash": "sha256-LW+2Yka4la4pC2QzdVYsEptmeYkYyKiQVeEzFcmVjYM=",
      "url": "_framework/Microsoft.Extensions.Primitives.pphafqm2is.wasm"
    },
    {
      "hash": "sha256-L3o6ScQiBNjoEsgB31VKNkW9rtDoCuWxpDnaZmdLG9Q=",
      "url": "_framework/Microsoft.Extensions.Validation.9q24f4ufiz.wasm"
    },
    {
      "hash": "sha256-b3oDx6CnxrlJd3wQYFL7BPJaC0gtnVabH6OvSqSmP+0=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.r99mmn9mmt.wasm"
    },
    {
      "hash": "sha256-S1jJv+AZDuSVz9qBKOY7vdHxN0s5Syn5tGKhTHFjca0=",
      "url": "_framework/Microsoft.JSInterop.l4xclch662.wasm"
    },
    {
      "hash": "sha256-b0NzcQ/WhuEk6dfW+kfIRJw2zJIqtQiRTeQqmLlpaWI=",
      "url": "_framework/Radzen.Blazor.jjzinqqg0u.wasm"
    },
    {
      "hash": "sha256-oKLXkrqjOoZ6NeIAFkPutgugDJaeb9qjfKYCUVY5bhI=",
      "url": "_framework/System.Collections.Concurrent.wgcmmh0k20.wasm"
    },
    {
      "hash": "sha256-juNqZKuEyl1uUfaMPQvKseqNyrvxGDTuP8phoBe6R88=",
      "url": "_framework/System.Collections.Immutable.2v7vqwpxnc.wasm"
    },
    {
      "hash": "sha256-Y+dSww8n4fYqOMnLDnnZfV/qNpN2ranBJdr3uDCwa1k=",
      "url": "_framework/System.Collections.NonGeneric.jkwi6vtw50.wasm"
    },
    {
      "hash": "sha256-cjeDA7Afm102QdBEt2cB/HdsgNFHIXksKN9prNnsQLs=",
      "url": "_framework/System.Collections.Specialized.242nd0yipv.wasm"
    },
    {
      "hash": "sha256-kgVCRszPcEoUGPGdb6Hcmq8Dgr/2Jxwuh8wIRHfucEw=",
      "url": "_framework/System.Collections.a2cexcqftw.wasm"
    },
    {
      "hash": "sha256-w8kjX6l9HfCvAhekRkmt6Z5Ke2CxPOenDWyAhZX/iiM=",
      "url": "_framework/System.ComponentModel.9h13ohdho8.wasm"
    },
    {
      "hash": "sha256-7+GeywyPd6EU36Qvqv+JW4DBKaDtx33jTVz+QuiQT2o=",
      "url": "_framework/System.ComponentModel.Annotations.zbkss8xfp2.wasm"
    },
    {
      "hash": "sha256-7pzo2hVvi/BVIrXsjnNg+OUeKQAAtKbI8Y0zSvLJ0Lw=",
      "url": "_framework/System.ComponentModel.Primitives.uwh9ebcxrw.wasm"
    },
    {
      "hash": "sha256-R8k9JJMjBIa9/9UI6LBbJNz9UojSoHvqTwu/f/g3PLE=",
      "url": "_framework/System.ComponentModel.TypeConverter.he3qnn7sdu.wasm"
    },
    {
      "hash": "sha256-TFVKgXgFR5O19GkTiWrMOhFpQp6+m6Y6o8rHA3ehrwo=",
      "url": "_framework/System.Console.g5r17pc5nl.wasm"
    },
    {
      "hash": "sha256-v69fvMyRw2MLYdCm6c8qEDEkwXngA3Mc83Q+EdySs3s=",
      "url": "_framework/System.Core.vkph4sefmh.wasm"
    },
    {
      "hash": "sha256-VH2JbXHWdqhZAsuNZg7qx5uOjWFo6WpupIjx1NGsvxw=",
      "url": "_framework/System.Data.Common.k8m7lfsi8v.wasm"
    },
    {
      "hash": "sha256-/A06mgEjCmbJ4GQkl5IZO9qhGyYX23kVgOw8x/AT75Q=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.ozkrnms4od.wasm"
    },
    {
      "hash": "sha256-f/OUjzpoXORRiy71/4AVWxsGxILDtvZWdv6ArOEs6qE=",
      "url": "_framework/System.Drawing.3viw894b88.wasm"
    },
    {
      "hash": "sha256-Tllbj1f53qkjrwPuo05qu2UUb+nBv7sOvoJTNyHgJQU=",
      "url": "_framework/System.Drawing.Primitives.2ja0kwddtj.wasm"
    },
    {
      "hash": "sha256-cMiCymfILOwfpSpM1XVT6EWpk4+qZ0djyeZE+xuHjbg=",
      "url": "_framework/System.IO.Pipelines.sly5as9fvq.wasm"
    },
    {
      "hash": "sha256-T7xC2Jn5ihSORyvq+Z1UsnZ84gWPWCj6RP+Ehvl+O84=",
      "url": "_framework/System.Linq.Expressions.18he9jehxj.wasm"
    },
    {
      "hash": "sha256-wbTIVeP/beYafXMfaS7JH4jrrb8U92My/POTVxXTjrU=",
      "url": "_framework/System.Linq.Queryable.t9ixen9jfk.wasm"
    },
    {
      "hash": "sha256-x2Y2kH8FfC4iof37LraJuhRbEPSbAebTnt/0aVdGIl4=",
      "url": "_framework/System.Linq.ver8ac7b2e.wasm"
    },
    {
      "hash": "sha256-nrKYE5t5K9UQrg7oRbyAufOy1isxDOp6UwsmLYnZbZA=",
      "url": "_framework/System.Memory.qtn0ennx4i.wasm"
    },
    {
      "hash": "sha256-LXqsichS16bCvXtGnrjgh3Md+tihR3vnCVDHYnwPoqY=",
      "url": "_framework/System.Net.Http.Json.f5dh1qeooy.wasm"
    },
    {
      "hash": "sha256-mGvNoqbtZrzLZJhNsNQlCcuNsRsvMK3JMayh5Eq2hAM=",
      "url": "_framework/System.Net.Http.cfsqe5wari.wasm"
    },
    {
      "hash": "sha256-wAP39lrPxd24Aksv911Fc9QeQhlMtivWi6RANnW+0+Q=",
      "url": "_framework/System.Net.Primitives.g0joan8ok8.wasm"
    },
    {
      "hash": "sha256-A22CuO+w3YChYU41RLgPOy8cLwrZiA4ohhtghcp9v7g=",
      "url": "_framework/System.ObjectModel.9hlx0ya5a9.wasm"
    },
    {
      "hash": "sha256-//dm4S8qOu15dcWKjkfAZl7C5gQupMH5FmfK2MmkN0Y=",
      "url": "_framework/System.Private.CoreLib.zfsc9tej1k.wasm"
    },
    {
      "hash": "sha256-g8v8Q3xZI8LwnsFdpDoohQWjVHeT9NyrEb3pHAFRj6c=",
      "url": "_framework/System.Private.Uri.p9ay8555y1.wasm"
    },
    {
      "hash": "sha256-7caKFfMUyPDLbXNBdKyC5W1IVcWVd9cIWKSg5WXBZf4=",
      "url": "_framework/System.Private.Xml.Linq.7ffoxlq037.wasm"
    },
    {
      "hash": "sha256-pXrQ1Rr6HrlOhkHS72IKgSbHmtEPULrt8rREdiUqi4c=",
      "url": "_framework/System.Private.Xml.tqivimas1v.wasm"
    },
    {
      "hash": "sha256-sCNaE26yFeJyyqn2pmn+DmvHOW6W1c5r8p8wki66HwU=",
      "url": "_framework/System.Reflection.Emit.08517zwm68.wasm"
    },
    {
      "hash": "sha256-X8VMkL78f8zl8gs6RfALZaHdm057P+9K8z2TrNbbqSE=",
      "url": "_framework/System.Reflection.Emit.ILGeneration.5zrci05qf4.wasm"
    },
    {
      "hash": "sha256-lvQRu8HVW0Oi/FFIOhFbm8Rh91NbibGtoCWYsjtHfho=",
      "url": "_framework/System.Reflection.Primitives.65rsbezu43.wasm"
    },
    {
      "hash": "sha256-Cp2bQOeRFVxMIA/IQbNc6pVyPdKopwM4EnwXZAse2KM=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.uzoakn3mog.wasm"
    },
    {
      "hash": "sha256-hRKk/mTbKOvEiiMNlxO5KeZXI1qIZfVKPN5bbnFRTUI=",
      "url": "_framework/System.Runtime.InteropServices.v3fgp5l84q.wasm"
    },
    {
      "hash": "sha256-FvQSBX4nPvQiAgW5NSsCmuDbveafgF+U2YJJX2reNqg=",
      "url": "_framework/System.Runtime.embhj3s06x.wasm"
    },
    {
      "hash": "sha256-o9voVsKALBUH/3c3GjtsMigMk6d3Rr1rpv4zeEQLhO4=",
      "url": "_framework/System.Security.Claims.zwwkcjkg71.wasm"
    },
    {
      "hash": "sha256-FrsOY8zOQD81TGKDEh0mP3ZICBl00LE3furOw7bToxY=",
      "url": "_framework/System.Security.Cryptography.6wps1yap4a.wasm"
    },
    {
      "hash": "sha256-grMY4M0k8p9y9MREo8l+5RNL6efy7B8EG4ymwcIG62U=",
      "url": "_framework/System.Text.Encodings.Web.q6hehx1i4q.wasm"
    },
    {
      "hash": "sha256-bGFJB5FO/RTlRTs5FTi+ydaGKTRorxGO8cMPGx3z+JM=",
      "url": "_framework/System.Text.Json.k825gh9iku.wasm"
    },
    {
      "hash": "sha256-46sKV9WoaRgfKTJ06eDOTsz+nUHFCMpfR9clBTw+M3g=",
      "url": "_framework/System.Text.RegularExpressions.v5hofk0ww7.wasm"
    },
    {
      "hash": "sha256-hNrDFtOWEF1g2Rgqlz+zM90S1gHj+8ooh1lbC8Ya3wY=",
      "url": "_framework/System.Threading.83lzpf7jyk.wasm"
    },
    {
      "hash": "sha256-/c3k4DddsfTkctWfiqSEupb8ygRAN4IPO7uZ1kjzYH4=",
      "url": "_framework/System.Web.HttpUtility.v92a8shsad.wasm"
    },
    {
      "hash": "sha256-T+9RdfUBfnlvro21wk8VmmYe3ZDfKiYEBbJPCfLiuds=",
      "url": "_framework/System.Xml.Linq.7qmldn65vo.wasm"
    },
    {
      "hash": "sha256-98Juu410m7xA9HgROwSepPIO18xwGABVNiVc4529598=",
      "url": "_framework/System.Xml.XDocument.v6g8vwwz54.wasm"
    },
    {
      "hash": "sha256-TbXBiQa38E2TrjWSwZYk9l9sTztp8pQ4MLJyVPBpaEk=",
      "url": "_framework/System.nnqvudo0vd.wasm"
    },
    {
      "hash": "sha256-A59Tr9HqEhHMu8kU7kruLI9ayw5MRS6Lvc6z7jCbghk=",
      "url": "_framework/blazor.webassembly.958z1vx7fr.js"
    },
    {
      "hash": "sha256-tZxqPllECDUpzS7ztZD9n63HJPuu+fckwrRKiiI3ogY=",
      "url": "_framework/dotnet.5sck7qt506.js"
    },
    {
      "hash": "sha256-+Pt+BJtPQo82vplwwUTBdJwWh79VwJx7Qot90mnILz0=",
      "url": "_framework/dotnet.native.gmluzg3jyg.wasm"
    },
    {
      "hash": "sha256-WGKuaVZHNCQJJ5NcB4x6tMiZNhZr3E2SuuVqqOsDFnI=",
      "url": "_framework/dotnet.native.wq5toy4mf1.js"
    },
    {
      "hash": "sha256-7i3usfTrnzC/9qWO4si5Bw4w7D9fUSnSBdhQ47blX2M=",
      "url": "_framework/dotnet.runtime.a6jcqbs390.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-NNyN9kssaxPuUKKgfUPnW6xM+ej0EAFwSCzFmxMJOyM=",
      "url": "appsettings.GitHub.json"
    },
    {
      "hash": "sha256-QRRz1OakeNknbxsHIcC/6Ba2mOpfJFp43WZ3cqIuKpk=",
      "url": "appsettings.Production.json"
    },
    {
      "hash": "sha256-5xgBj50mDD7rxU1lP8w4nVqg4RlO3GnqEDeDF0fPdfQ=",
      "url": "appsettings.json"
    },
    {
      "hash": "sha256-Bu7Jhk75uSxZKLwOCFkuwoYklHzZbIdYw7TavxqWJ/o=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-CgXJi5UgnLBPHwuD4OIiplZGAH8SmBrlBBzRxeZ3QJY=",
      "url": "index.html"
    },
    {
      "hash": "sha256-fjBMU0TSFaXtkjC7c7fnmiMVC5LdUPg7psR3LrPmJHI=",
      "url": "js/connectivity.js"
    },
    {
      "hash": "sha256-WJcQqATylKST/HOKGlYUP8wNd7sx2tOXWCdKF5E/kNo=",
      "url": "js/fieldCamera.js"
    },
    {
      "hash": "sha256-5bs46p1Esth3NIuNgUNuzQtgeVNNd46npgAhRi8S4Jw=",
      "url": "js/fieldMaps.js"
    },
    {
      "hash": "sha256-lRM5e2isTZTg3+YMXV8wj5Ih8xPfg5KO5bT89vE9j00=",
      "url": "js/fieldSensors.js"
    },
    {
      "hash": "sha256-BLc+gOjPyhl0vwdE4kgulSASuLXAX4SQR1yWFvW0hAY=",
      "url": "js/fieldShare.js"
    },
    {
      "hash": "sha256-nKdrMry4Nz4O5Mm9IrBf0nHC2/NvM1NcrT/yzAJjzOY=",
      "url": "js/indexedDbService.js"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-HwPEeqzxKRA+z0H43/vTnWKy7sQLgc8ZZ1Qm/kSS3Nk=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-kUim9pqPRK1Hwdq96qF1F05+D+zwzvbfJ7mIlR08Dag=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-gTIm85WdarfhciNy9LC3iswahcrhHabaGGZd2rUwMhA=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-Mgwd4CwZjs8GEFpy2ErN1jyreJP6OC97p9SIGCYGnCk=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-EUhv9/bhIJUtlyCDEWriid3aO6qZv3AMjjH7emEpoPY=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-DJlFrzbrus6xcWsVUGWq2Cu6IfMDBAEZYc5qqU7MnwM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-F/jgmCzhz5rdR2pqoRE9UW/d7brTWHYmGbIUjMJMxXs=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-UeTa2SgexZHVzkBvZ+VSc2EU++fIkiu6cnE9fO6ZBM4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-jOpMCaiFLYdXM5FBSxzGSn6OeDtLSLiN9koclpx1JjE=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-A3/ygJMQ5xcYejifd49/kpXu/x8x7ldSm6RFyRdkMZ8=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-iRobWIPxHEAcQ3GnAVETRVu7Y2jtCGN7CyN7dy0tOnA=",
      "url": "sample-data/South Africa/African National Congress/assignments.json"
    },
    {
      "hash": "sha256-mM/TCQi2td5FUc76614qmB0S5x3fgfSLbj0ClN33cmU=",
      "url": "sample-data/South Africa/African National Congress/broadcasts.json"
    },
    {
      "hash": "sha256-m9M43NWYB6pz0uawYCu6J44tKQAEVgtr5A50WCKoFwo=",
      "url": "sample-data/South Africa/African National Congress/campaigns.json"
    },
    {
      "hash": "sha256-QQWgrZsjYCzK8FdmXNTsMZwZWS2HbDhRBwWw30BnbEw=",
      "url": "sample-data/South Africa/African National Congress/follow-ups.json"
    },
    {
      "hash": "sha256-dictrJ6HISS4ni5TKungyznOrZre3bAAjVepS73/1E8=",
      "url": "sample-data/South Africa/African National Congress/results.json"
    },
    {
      "hash": "sha256-dVPNvDwPGeeNFyFZvZrownZz/Ntjd+KvwdjCr6mpfIs=",
      "url": "sample-data/South Africa/African National Congress/voters.json"
    },
    {
      "hash": "sha256-/NyWDMFu6yWB5DwN7TytRrIEzXo1NJfvdsuBaDejNzI=",
      "url": "sample-data/South Africa/Democratic Alliance/assignments.json"
    },
    {
      "hash": "sha256-vq21v1O9SLEHUjCcgTrcPGSiFmttq+BVlkSxe1PNSss=",
      "url": "sample-data/South Africa/Democratic Alliance/broadcasts.json"
    },
    {
      "hash": "sha256-SorftYtWZR6bNGDXZTcv90QCkjYXjMHTgKS8QxefINE=",
      "url": "sample-data/South Africa/Democratic Alliance/campaigns.json"
    },
    {
      "hash": "sha256-XSqkcJvff7uoGdkkeqltfAWWqtcicghU11zj+U21+7Y=",
      "url": "sample-data/South Africa/Democratic Alliance/follow-ups.json"
    },
    {
      "hash": "sha256-74znJ177fnqiDtLLYsLcP0B98LsrJXF4K4N2JqYWbbg=",
      "url": "sample-data/South Africa/Democratic Alliance/results.json"
    },
    {
      "hash": "sha256-/TBph3VovBrrE6pXFhKph6+xa9N9he/J59QfqN1QqaQ=",
      "url": "sample-data/South Africa/Democratic Alliance/voters.json"
    },
    {
      "hash": "sha256-VGWY8xRC5ghEjy6wNS4Ee1lDA6I6fFMiPIGmMb1MEUg=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/assignments.json"
    },
    {
      "hash": "sha256-VYY+lBcSN999r2IZC05nZMmbFCXjn2MVJ3RPetVpjLo=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/broadcasts.json"
    },
    {
      "hash": "sha256-uhJQWtMqiUOTSdcJwvyFkabOwq8e73EC1FrFCjTd88w=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/campaigns.json"
    },
    {
      "hash": "sha256-I+MDJ4zozW2WBhOEqL3xjlCPNbUCKyuuLNy4g2tKIXI=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/follow-ups.json"
    },
    {
      "hash": "sha256-pTONlVsJBG7AsW86liW3lVx2Oq4H3HIuR05geHRfky8=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/results.json"
    },
    {
      "hash": "sha256-cQiYAjmJcgELiD2dhv6eaAq/MyrNUMZ4GmRvc+ioCtE=",
      "url": "sample-data/South Africa/Economic Freedom Fighters/voters.json"
    },
    {
      "hash": "sha256-RLlzlbuK5e6P4wsVhlYsRGwdk1nTfAHeWbDExNe08oI=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/assignments.json"
    },
    {
      "hash": "sha256-6+jM2olEattoukivaSlOqliFaQgrGlUQxYqHMqEtcUk=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/broadcasts.json"
    },
    {
      "hash": "sha256-+UmNRZcMuixVGVH+8Q3nfGiTEQGJAXQ+XBB4Ev0SaEM=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/campaigns.json"
    },
    {
      "hash": "sha256-R7SE48LzUJpiccSW8/ZdtmwmtYfmh+99q+BZp9s5V2Y=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/follow-ups.json"
    },
    {
      "hash": "sha256-pTONlVsJBG7AsW86liW3lVx2Oq4H3HIuR05geHRfky8=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/results.json"
    },
    {
      "hash": "sha256-NSlb/UCgNriUt7vV2M1Cr4OHKflmK2pixo/eiMmk/VM=",
      "url": "sample-data/South Africa/uMkhonto weSizwe/voters.json"
    },
    {
      "hash": "sha256-jU+WMMBGMY8MKvXh+dXcKGzutS9jcEsjs9lZ1Y4wA0A=",
      "url": "sample-data/Zambia/Citizen First/assignments.json"
    },
    {
      "hash": "sha256-eUnOXjchwAv98vEf7WU0uAkVHaLWK4QBSEalIMvJ/E8=",
      "url": "sample-data/Zambia/Citizen First/broadcasts.json"
    },
    {
      "hash": "sha256-7Cvl0AtfIY24IKsrxQy2CwdFf4zVVUSHysYb0cGVAtI=",
      "url": "sample-data/Zambia/Citizen First/campaigns.json"
    },
    {
      "hash": "sha256-g3ydzY5URMNZAr/0LNRSEyZE7bBDNTqItkSdFxpX9Gg=",
      "url": "sample-data/Zambia/Citizen First/follow-ups.json"
    },
    {
      "hash": "sha256-ohiKk/WfH2BO1r3tVl6jdoN+1f99JW4Qz+eEfRPcqaQ=",
      "url": "sample-data/Zambia/Citizen First/results.json"
    },
    {
      "hash": "sha256-7T/GzcXJYbNdbRKbUh2RucImZRVQh+1VMZ6dnGKGe0g=",
      "url": "sample-data/Zambia/Citizen First/voters.json"
    },
    {
      "hash": "sha256-1EcYx2DETTQFgUuAdVLmoSkgU3qtm0uBSpfbQegbO5c=",
      "url": "sample-data/Zambia/Patriotic Front/assignments.json"
    },
    {
      "hash": "sha256-1dFVh0PcaJbyosmA2gaOrAglO1UJDWRZ8Lsls0gSxxo=",
      "url": "sample-data/Zambia/Patriotic Front/broadcasts.json"
    },
    {
      "hash": "sha256-AN3dW72HvierWSPq6i1AI9RwSHTZgwSO2wx41gKEC/c=",
      "url": "sample-data/Zambia/Patriotic Front/campaigns.json"
    },
    {
      "hash": "sha256-mE4J8DcVpeZxxrReWLl4wlVVxqGqCELw/nnz47GNkHk=",
      "url": "sample-data/Zambia/Patriotic Front/follow-ups.json"
    },
    {
      "hash": "sha256-iZ2qKNPpuSTWM1Sky3XQsYEeoDuW9bRxg/3xX09x2zY=",
      "url": "sample-data/Zambia/Patriotic Front/results.json"
    },
    {
      "hash": "sha256-ZGLCotQz5zp0CabwIXbNitNJ1AQrTsOMUOAliVexgVc=",
      "url": "sample-data/Zambia/Patriotic Front/voters.json"
    },
    {
      "hash": "sha256-VyB1qdK3TyOa0RP18cXGPZcWw8+26mZqEFLxkslKqAc=",
      "url": "sample-data/Zambia/Socialist Party/assignments.json"
    },
    {
      "hash": "sha256-FZg3aTt6DavQHyxT0YIxaw0B07y7N2/Jto7Vze9OoLk=",
      "url": "sample-data/Zambia/Socialist Party/broadcasts.json"
    },
    {
      "hash": "sha256-d3Ex3UQiityZqRHm6RzGq6C/cTf+Qcl33LQmPqu1WP0=",
      "url": "sample-data/Zambia/Socialist Party/campaigns.json"
    },
    {
      "hash": "sha256-IN7CZRclP6k5oYzothZcSma3ONgBUptLPlUTzKdIbaE=",
      "url": "sample-data/Zambia/Socialist Party/follow-ups.json"
    },
    {
      "hash": "sha256-xninYqLo4SJUKjIWQcAk4R36kQnASVrv1oYd5wRj/W4=",
      "url": "sample-data/Zambia/Socialist Party/results.json"
    },
    {
      "hash": "sha256-sfMxZp0LdPfaBR5W3QS7f76PZBhZmmEqARW+mEiLZzM=",
      "url": "sample-data/Zambia/Socialist Party/voters.json"
    },
    {
      "hash": "sha256-3Ism7LV7811yt41e9/St2gjNQzN8hQvxNQvi/x/2Jt4=",
      "url": "sample-data/Zambia/United Party for National Development/assignments.json"
    },
    {
      "hash": "sha256-zmqRoe0NuwsEd8FITnZu/m6xNpjrHkPtuvgeUDdsxl4=",
      "url": "sample-data/Zambia/United Party for National Development/broadcasts.json"
    },
    {
      "hash": "sha256-M982iEoR1cU0eZzuTgW8BHjocK28eEWvwaUQsYZSfbI=",
      "url": "sample-data/Zambia/United Party for National Development/campaigns.json"
    },
    {
      "hash": "sha256-I+HybtKfujJjElofdzGusI4SM+4dqw/YZUwPTpIdIUE=",
      "url": "sample-data/Zambia/United Party for National Development/follow-ups.json"
    },
    {
      "hash": "sha256-I7OvbZpZGGfoLJxdiKz3h0jLNfAc9gniTi8KHwUtMRs=",
      "url": "sample-data/Zambia/United Party for National Development/results.json"
    },
    {
      "hash": "sha256-BxqRLZBsNN2O6p/8l97o7/Bb5omEekuZ0lkmSZzrMDQ=",
      "url": "sample-data/Zambia/United Party for National Development/voters.json"
    },
    {
      "hash": "sha256-npu4f4oEo+H9jBkzLeH8t+A5T4cUr9iMDJGf/6LEyAw=",
      "url": "sample-data/auth-config.json"
    },
    {
      "hash": "sha256-c275Bx0cUpfc1DjajNQn4es9+UhfIxcUJ3HQGF8uKsw=",
      "url": "sample-data/field-catalogs.json"
    },
    {
      "hash": "sha256-umGP1JvxVrx4DIfjatJwxoeoovSPoNCNncoKgDD6j+4=",
      "url": "sample-data/observer-incident-form.bem.json"
    },
    {
      "hash": "sha256-rlySrr53fxjRZiN7I4gNRMWAzyb90xGGW57uVxdiRSI=",
      "url": "sample-data/observer-incident-form.en.json"
    },
    {
      "hash": "sha256-bALjp5743GWIVLGn9ZEf2WnxvmuzgDEWRGuGP6JKPZo=",
      "url": "sample-data/observer-incident-form.fr.json"
    },
    {
      "hash": "sha256-rlySrr53fxjRZiN7I4gNRMWAzyb90xGGW57uVxdiRSI=",
      "url": "sample-data/observer-incident-form.json"
    },
    {
      "hash": "sha256-YLAvagOLaTfZ/DsbZGrZewDpD5Kp0PMkWVp5g0uhpp4=",
      "url": "sample-data/observer-incident-form.ny.json"
    },
    {
      "hash": "sha256-uy2atgNzlrY48TCNaEkAqQtG+HTe4Qv/6DvHX55hFKA=",
      "url": "sample-data/observer-incident-form.toi.json"
    },
    {
      "hash": "sha256-80unkJJyOmNySjS0/vBEE3VNYJGY/p4hUNyVUuKCc/M=",
      "url": "sample-data/search-config.json"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
